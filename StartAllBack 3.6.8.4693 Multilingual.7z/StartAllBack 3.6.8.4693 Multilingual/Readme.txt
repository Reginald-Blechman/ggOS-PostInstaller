﻿1. Install (update) StartAllBack
2. Disable Windows Defender (or other antivirus)
3. Run and apply the patch
4. Enable antivirus
5. Done